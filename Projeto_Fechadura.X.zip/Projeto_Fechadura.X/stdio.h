#ifndef STDIO_H
#define STDIO_H

void printf(char texto[32]);

void printn(int num);


#endif  //STDIO_H

